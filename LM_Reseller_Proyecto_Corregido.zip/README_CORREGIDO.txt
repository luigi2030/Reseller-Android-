L&M Reseller Android project (corrected structure)

This ZIP contains a clean Android project structure. The original repository had:
- the root Gradle file named `build.grade` instead of `build.gradle`;
- the AndroidManifest.xml outside `app/src/main/`;
- duplicated nested folders;
- a workflow in a misspelled folder path.

For GitHub Actions, upload/extract these files into the repository root so that `.github/workflows/build-apk.yml`,
`build.gradle`, `settings.gradle`, and `app/` are at the top level. Then open GitHub Actions, choose
“Build L&M Reseller APK”, and press “Run workflow”. When successful, download the `LM-Reseller-APK` artifact.
